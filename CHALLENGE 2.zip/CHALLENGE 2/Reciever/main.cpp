// Authors: Aisha Shareef (S1900266) & Nuha Ali (S1800181) 
//Description: score board                  

#include "MicroBit.h"
    
MicroBit uBit; 
MicroBitPin P0(MICROBIT_ID_IO_P0, MICROBIT_PIN_P0, PIN_CAPABILITY_DIGITAL); 
int score; // Defines the score 
    
    
// Tracks the time between 1 and 0 from the incoming signal on GPIO pin P0
// The time tracked determines what action is performed by the microbit
// If the TotalTracked is "300" it will add 1 to the running score
// If the TotalTracked is "200" it will trigger the game over functon and reset the microbit

     
int DetectSignal() {
    while (1) {
            
        if (P0.getDigitalValue()) { // Checks for incoming signal 
            int StartTime = uBit.systemTime(); // Gets the time from last microbit reset
                
            while(P0.getDigitalValue()) {} // Waits for the pulse sent through the sender to end
                int TotalTracked = uBit.systemTime() - StartTime; // Determines the length of the incoming pulse
                
            if (TotalTracked > 50) { // An extra step to make sure the signal was valid
                return TotalTracked;
                
            }
        }
    }   
}
    
// Checks to see if the incoming signal fits into the determined range so it can be treated as a verified signal    
bool VerifiedSignal(int incoming, int pulse, int margin) {
        
    if ((incoming < (pulse + margin)) && (incoming > (pulse - margin))) {
            return true;
           
        } else {
            return false;
        }
    }

// Scoreboard for the game being played on the connected microbit. Displays running and final score.
void HandlePulse() {

int SignalType = DetectSignal();
            
    if (VerifiedSignal(SignalType, 300, 25)) { // Determines that if a pulse of 300 is received the score increments by 1
            score++;
                    
            if(score < 10){
                uBit.display.print(score); // Scores below 10 are printed
                    
                    
    } else if (VerifiedSignal(SignalType, 200, 25)) { // Determines that if a pulse of 200 is received the game has ended
           
        uBit.display.scroll("Score:"); // The final score is displayed before being reset
        uBit.display.scroll(score);
        uBit.sleep(100);
        uBit.reset(); 
    }     
}
    
int main()
;{
    uBit.init(); // Initialises the microbit
    score = 0; // Initialises score
    uBit.display.print(score); 
        
    while (1){
           
        HandlePulse(); // Runs the scoreboard  
    }
}
}