// Authors: Aisha Shareef (S1900266) & Nuha Ali (S1800181) 
// Description: Game-world of chicken invaders 

#include "MicroBit.h"
 
#define GAME_ON         0
#define GAME_OVER       1
 
struct Point
{
    int     x;
    int     y;
};
 
MicroBit        uBit;
MicroBitImage   invaders(5,5);
float           score; 
int             game_over;
int             level;
int             INVADER_SPEED = 750;
int             PLAYER_SPEED = 150;
int             BULLET_SPEED = 50;
Point           player;
Point           bullet;
MicroBitPin P0(MICROBIT_ID_IO_P0, MICROBIT_PIN_P0, PIN_CAPABILITY_DIGITAL);
 
// Add a new row of chicken invaders to the game.

int addRow()
{
    // If out of space, game over!!
    for (int x=0; x<5; x++)
        if (invaders.getPixelValue(x,4))
            return GAME_OVER;
 
    // Else, move down the invaders, and add a new row at the top.
    invaders.shiftDown(1);
 
    for (int x=1; x<4; x++)
        invaders.setPixelValue(x,0,255);
 
    return GAME_ON;
}
void SendPulse(int PulseLength)
{
    P0.setDigitalValue(1);
    uBit.sleep(PulseLength);
    P0.setDigitalValue(0);
    uBit.sleep(100);
}

// Display Game Over and show the player's score.

void gameOver()
{
    uBit.sleep(600); // Required to let the reciever finish scrolling double digits before receiving the game over pulse
    uBit.display.clear();
    SendPulse(200); // Sends a pulse of length "200" to trigger the receiver to display final score and reset
    uBit.display.scroll("GAME OVER!");
    uBit.sleep(100);
}


// Calculate the speed of an invaders movement, based on the game level
int invaderSpeed()
{
    return max(INVADER_SPEED - level*50, 50);
}
 

// Determine if the are any invaders in the given column

bool invadersInColumn(int x)
{
    for (int y = 0; y < 5; y++)
        if (invaders.getPixelValue(x,y))
            return true;
 
    return false;
}
 
// Determine the number of invaders currently on screen

bool invaderCount()
{
    int count = 0;
 
    for (int x=0; x<5; x++)
        for (int y=0; y<5; y++)
            if (invaders.getPixelValue(x,y))
                count++;
 
    return count;
}
 
// Move chicken invaders on the screen.

void invaderUpdate()
{
    bool movingRight = true;
 
    while(!game_over)
    {   
        uBit.sleep(invaderSpeed());
 
        if (movingRight)
        {
            if(invadersInColumn(4))
            {
                movingRight = false;
                if (addRow() == GAME_OVER)
                {
                    game_over = true;
                    return;
                }
            }
            else
            {
                invaders.shiftRight(1);
            }
        }
        else
        {
            if(invadersInColumn(0))
            {
                movingRight = true;
                if (addRow() == GAME_OVER)
                {
                    game_over = true;
                    return;
                }
            }
            else
            {
                invaders.shiftLeft(1);
            }
        }
 
        if (invaderCount() == 0)
        {
            level++;
            addRow();
        }
    }
}
 
 
// Move the bullet up the screen
void bulletUpdate()
{
    while (!game_over)
    {
        uBit.sleep(BULLET_SPEED);
        if (bullet.y != -1)
            bullet.y--;
 
        if (invaders.getPixelValue(bullet.x, bullet.y) > 0)
        {
            score++;
            invaders.setPixelValue(bullet.x, bullet.y, 0);
            bullet.x = -1;
            bullet.y = -1;
        }
    }
}
 
// Move the player across the screen.

void playerUpdate()
{
    while (!game_over)
    {
        uBit.sleep(PLAYER_SPEED);
 
        if(uBit.accelerometer.getX() < -300 && player.x > 0)
            player.x--;
 
        if(uBit.accelerometer.getX() > 300 && player.x < 4)
            player.x++;
    }
}
 
// Fire a new missile from the player

void fire(MicroBitEvent)
{
    if (bullet.y == -1)
    {
        bullet.y = 4;
        bullet.x = player.x;
    }
}
 
// A simple game of chicken invaders
void chickenInvaders()
{   
    // Reset all game state.
    game_over = 0;
    level = 0;
    score = 0;
    player.x = 2;
    player.y = 4;
 
    bullet.x = -1;
    bullet.y = -1;
 
    // Add a single row of invaders at the start
    invaders.clear();
    addRow();
 
    // Spawn independent fibers to handle the movement of each player
    create_fiber(invaderUpdate);
    create_fiber(bulletUpdate);
    create_fiber(playerUpdate);
 
    // Register event handlers for button presses (either button fires!)
    uBit.messageBus.listen(MICROBIT_ID_BUTTON_A, MICROBIT_BUTTON_EVT_CLICK, fire);
    uBit.messageBus.listen(MICROBIT_ID_BUTTON_B, MICROBIT_BUTTON_EVT_CLICK, fire);
 
    while (!game_over)
    {    
        uBit.sleep(10);
        uBit.display.image.paste(invaders);
        uBit.display.image.setPixelValue(player.x, player.y, 255);
        uBit.display.image.setPixelValue(bullet.x, bullet.y, 255);
    }
 
    // Display game over and score
    gameOver();
}
 
int main()
{
    // Initialise the micro:bit runtime.
    uBit.init();
 
    // Welcome message
    uBit.display.scroll(" CHICKEN INVADERS!");
 
    // Keep playing forever
    while(1)
        chickenInvaders();
}
 
 